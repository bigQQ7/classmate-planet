import { env } from 'cloudflare:workers';
import { getChatGPTUser } from '../../../chatgpt-auth';
export async function GET(request: Request, context: {params: Promise<{id:string}>}) {
  if(!await getChatGPTUser()) return new Response('Unauthorized',{status:401});
  const {id}=await context.params;
  if(!/^[a-f0-9]{64}$/.test(id)) return new Response('Not found',{status:404});
  const object=await env.BUCKET?.get('avatars/'+id);
  if(!object) return new Response('Not found',{status:404});
  return new Response(object.body,{headers:{'Content-Type':object.httpMetadata?.contentType||'image/webp','Cache-Control':'private, max-age=3600','X-Content-Type-Options':'nosniff'}});
}
