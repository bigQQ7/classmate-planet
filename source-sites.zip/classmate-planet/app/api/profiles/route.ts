import { env } from 'cloudflare:workers';
import { getChatGPTUser } from '../../chatgpt-auth';
export const dynamic = 'force-dynamic';
async function identity() {
  const user = await getChatGPTUser();
  if (!user) return null;
  const hash = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(user.userId));
  return Array.from(new Uint8Array(hash)).map(x=>x.toString(16).padStart(2,'0')).join('');
}
const reply = (data: unknown, status=200) => Response.json(data,{status, headers:{'Cache-Control':'no-store'}});
export async function GET() {
  try {
    const id = await identity();
    if (!id) return reply({error:'请先登录后进入同学星球。'},401);
    if (!env.DB) return reply({error:'同学墙暂时不可用，请稍后重试。'},503);
    const result = await env.DB.prepare('SELECT id, data FROM profiles ORDER BY updated DESC LIMIT 500').all<{id:string;data:string}>();
    let mine = null;
    const profiles = result.results.map(row=>{
      const data=JSON.parse(row.data);
      if(row.id===id) mine={...data,id};
      const {wechat,age,...publicData}=data;
      return {...publicData,id:row.id, age:data.showAge?age:null, wechat:data.showWechat?wechat:null};
    });
    return reply({profiles:mine?profiles:[],mine});
  } catch { return reply({error:'暂时无法加载同学资料，请重试。'},503); }
}
export async function POST(request: Request) {
  try {
    if (request.headers.get('sec-fetch-site')==='cross-site') return reply({error:'请在网站内提交资料。'},403);
    const id=await identity();
    if(!id) return reply({error:'请先登录后提交资料。'},401);
    if(!env.DB || !env.BUCKET) return reply({error:'资料保存暂时不可用，请稍后重试。'},503);
    if(Number(request.headers.get('content-length')||0)>600000) return reply({error:'头像文件过大。'},413);
    const parsed=await request.json();
    if(!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return reply({error:'资料格式不正确。'},400);
    const input=parsed as Record<string,unknown>;
    const clean=(value:unknown,max:number)=>typeof value==='string'?value.trim().slice(0,max):'';
    const name=clean(input.name,24), wechat=clean(input.wechat,60), grade=clean(input.grade,30), goal=clean(input.goal,500), age=Number(input.age);
    const list=(value:unknown,max:number)=>Array.isArray(value)?Array.from(new Set(value.filter(v=>typeof v==='string'&&v.trim()).map(v=>v.trim().slice(0,40)))).slice(0,max):[];
    const interests=list(input.interests,12), goals=list(input.goals,8);
    if(!name || !wechat || !grade || !Number.isInteger(age) || age<5 || age>100 || !interests.length || (!goals.length&&!goal)) return reply({error:'请完整填写姓名、年龄、微信、年级、兴趣和学习期待。'},400);
    const previous=await env.DB.prepare('SELECT data FROM profiles WHERE id=?').bind(id).first<{data:string}>();
    let avatar=previous?JSON.parse(previous.data).avatar:'';
    if(input.avatarData) {
      if(typeof input.avatarData !== 'string') return reply({error:'头像格式不正确。'},400);
      const match=/^data:image\/(webp|png|jpeg);base64,([A-Za-z0-9+/=]+)$/.exec(input.avatarData);
      if(!match || match[2].length>400000) return reply({error:'请上传有效的头像图片。'},400);
      const raw=Uint8Array.from(atob(match[2]),c=>c.charCodeAt(0));
      if(raw.length>300000) return reply({error:'头像文件过大，请换一张图片。'},400);
      await env.BUCKET.put('avatars/'+id,raw,{httpMetadata:{contentType:'image/'+match[1]}});
      avatar='/api/avatar/'+id+'?v='+Date.now();
    }
    const data={name,age,wechat,grade,mbti:clean(input.mbti,16),zodiac:clean(input.zodiac,16),interests,goals,goal,avatar,showWechat:input.showWechat===true,showAge:input.showAge===true};
    await env.DB.prepare('INSERT INTO profiles (id,data,updated) VALUES (?,?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data,updated=excluded.updated').bind(id,JSON.stringify(data),Date.now()).run();
    return reply({ok:true});
  } catch {return reply({error:'保存失败，请检查网络后重试。'},500);}
}
