import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: '同学星球 · 找到你的创作搭子', description: 'IP课堂的同学小宇宙，记录自己，遇见同频的朋友。' };
export default function Layout({children}: {children: React.ReactNode}) {return <html lang="zh-CN"><body>{children}</body></html>}
