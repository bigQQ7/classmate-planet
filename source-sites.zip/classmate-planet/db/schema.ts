import { sqliteTable, text, integer } from 'drizzle-orm/sqlite-core';
export const profiles = sqliteTable('profiles', {
  id: text('id').primaryKey(),
  data: text('data').notNull(),
  updated: integer('updated').notNull(),
});
